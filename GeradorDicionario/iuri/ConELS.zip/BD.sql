DROP TABLE IF EXISTS Imagens
CREATE TABLE Imagens(Palavra text not null, Arquivo text not null)
INSERT INTO Imagens VALUES("Desculpa", "desculpa.png")
INSERT INTO Imagens VALUES("Obrigado", "obrigado.png")